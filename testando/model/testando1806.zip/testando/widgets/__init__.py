# -*- coding: utf-8 -*-
"""The testando package"""
