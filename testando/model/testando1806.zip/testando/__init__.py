# -*- coding: utf-8 -*-
"""The testando package"""
from testando import *