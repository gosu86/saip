function add_more_atrr()
{	
	var lider_id = $('<input type="text" name="lider_id" id="lider_id" value="" />');
	
	$(".submitbutton").before(newRow);

}